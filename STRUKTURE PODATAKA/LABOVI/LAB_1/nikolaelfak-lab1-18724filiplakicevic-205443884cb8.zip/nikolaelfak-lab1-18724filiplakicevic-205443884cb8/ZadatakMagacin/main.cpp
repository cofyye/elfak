#include "Stack.h"
#include <iostream>
using namespace std;

bool areParenthesesMatching(char* expression)
{
	//TODO: implementirati funkciju
	return true;
}

void main()
{
	char expression1[] = "5 + [2-(5+3/5)/(5+2)]";
	char expression2[] = "{4 + 2 / 10 +[(3*3)}";
	char expression3[] = "(8 + 10 / 20 ))";
	cout << areParenthesesMatching(expression1);
	cout << areParenthesesMatching(expression2);
	cout << areParenthesesMatching(expression3);
}