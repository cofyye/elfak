#include"OpenScatterTable.h"

void main()
{
	OpenScatterTable tablica(64);
	//TODO: dodati testiranje tablice prema zahtevu zadatka
}