#include"ChainedScatterTable.h"

void main()
{
	ChainedScatterTable tablica(64);
	//TODO: dodati testiranje tablice prema zahtevu zadatka
}