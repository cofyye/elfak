
// 18724_Filip_LakicevicDoc.h : interface of the CMy18724FilipLakicevicDoc class
//


#pragma once


class CMy18724FilipLakicevicDoc : public CDocument
{
protected: // create from serialization only
	CMy18724FilipLakicevicDoc() noexcept;
	DECLARE_DYNCREATE(CMy18724FilipLakicevicDoc)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// Implementation
public:
	virtual ~CMy18724FilipLakicevicDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// Helper function that sets search content for a Search Handler
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
};
