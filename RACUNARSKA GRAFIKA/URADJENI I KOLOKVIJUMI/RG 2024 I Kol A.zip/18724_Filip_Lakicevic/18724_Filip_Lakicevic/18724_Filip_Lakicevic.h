
// 18724_Filip_Lakicevic.h : main header file for the 18724_Filip_Lakicevic application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'pch.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CMy18724FilipLakicevicApp:
// See 18724_Filip_Lakicevic.cpp for the implementation of this class
//

class CMy18724FilipLakicevicApp : public CWinAppEx
{
public:
	CMy18724FilipLakicevicApp() noexcept;


// Overrides
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

// Implementation
	UINT  m_nAppLook;
	BOOL  m_bHiColorIcons;

	virtual void PreLoadState();
	virtual void LoadCustomState();
	virtual void SaveCustomState();

	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CMy18724FilipLakicevicApp theApp;
