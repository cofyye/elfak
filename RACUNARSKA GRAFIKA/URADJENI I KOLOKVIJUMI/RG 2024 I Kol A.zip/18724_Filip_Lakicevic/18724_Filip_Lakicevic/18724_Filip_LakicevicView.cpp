﻿
// 18724_Filip_LakicevicView.cpp : implementation of the CMy18724FilipLakicevicView class
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "18724_Filip_Lakicevic.h"
#endif

#include "18724_Filip_LakicevicDoc.h"
#include "18724_Filip_LakicevicView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#include "DImage.h"


// CMy18724FilipLakicevicView

IMPLEMENT_DYNCREATE(CMy18724FilipLakicevicView, CView)

BEGIN_MESSAGE_MAP(CMy18724FilipLakicevicView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CMy18724FilipLakicevicView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_WM_KEYDOWN()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()

// CMy18724FilipLakicevicView construction/destruction

float CMy18724FilipLakicevicView::DegToRad(float deg) {
	return deg * 3.14f / 180.0f;
}

CMy18724FilipLakicevicView::CMy18724FilipLakicevicView() noexcept
{
	// TODO: add construction code here

	//background = new DImage();

	m_imgBackground = new DImage();
	m_imgBasket = new DImage();
	m_imgArm = new DImage();

	m_imgBackground->Load(CString("./Slike/Background.jpg"));
	m_imgBasket->Load(CString("./Slike/Basket.png"));
	m_imgArm->Load(CString("./Slike/Arm.png"));

	// ostale slike

	//background->Load(CString("./Slike/background.jpg"));

	// istali loadovi

}

CMy18724FilipLakicevicView::~CMy18724FilipLakicevicView()
{

	//delete background;

	delete m_imgBackground;
	delete m_imgBasket;
	delete m_imgArm;

	m_imgBackground = m_imgBasket = m_imgArm = nullptr;

	//ostali deleteovi
}

void CMy18724FilipLakicevicView::Translate(CDC* pDC, float dx, float dy, bool rightMultiply) {
	XFORM xf{ 1, 0, 0, 1, dx, dy };
	pDC->ModifyWorldTransform(&xf, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);
}

void CMy18724FilipLakicevicView::Scale(CDC* pDC, float sX, float sY, bool rightMultiply) {
	XFORM xform{};
	xform.eM11 = sX;
	xform.eM12 = 0.0;
	xform.eM21 = 0.0;
	xform.eM22 = sY;
	xform.eDx = 0.0;
	xform.eDy = 0.0;
	pDC->ModifyWorldTransform(&xform, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);
}

BOOL CMy18724FilipLakicevicView::OnEraseBkgnd(CDC* pDC) {
	return true;
}

// TEXT: Ako zatreba odkomentarisi
//void CMy18724FilipLakicevicView::Mirror(CDC* pDC, bool mx, bool my,
	//bool rightMultiply)
//{
	//Scale(pDC, mx ? -1 : 1, my ? -1 : 1, rightMultiply);
//}

// Crtanje pozadinske slike u prirodnoj velicini
/*
void CMy18724FilipLakicevicView::DrawBackground(CDC* pDC)
{
	CRect client;
	GetClientRect(&client);
	background->Draw(pDC, CRect(0, 0, background->Width(),
	background->Height()), client);
}
*/



/* Crtanje pozadinske slike tako da
je uvek centrirana po X-osi, prilikom promene veličine prozora, a donja
ivica se poklapa sa
donjom ivicom klijentskog dela prozora */
void CMy18724FilipLakicevicView::DrawBackground(CDC* pDC) {
	CRect client;
	GetClientRect(&client);
	int x, y, w, h;
	x = (client.Width() - m_imgBackground->Width()) / 2;
	w = x + m_imgBackground->Width();
	y = client.Height() - m_imgBackground->Height();
	h = y + m_imgBackground->Height();
	m_imgBackground->Draw(pDC, CRect(0, 0, m_imgBackground->Width(),
		m_imgBackground->Height()), CRect(x, y, w, h));
}

/*
void CMy18724FilipLakicevicView::DrawImgTransparent(CDC* pDC, DImage* pImage) {
	int w = pImage->Width();
	int h = pImage->Height();
	CBitmap bmpImage, bmpMask;
	bmpImage.CreateCompatibleBitmap(pDC, w, h);
	bmpMask.CreateBitmap(w, h, 1, 1, NULL);
	CDC* pSrcDC = new CDC();
	pSrcDC->CreateCompatibleDC(pDC);
	pSrcDC->SelectObject(bmpImage);
	CDC* pMaskDC = new CDC();
	pMaskDC->CreateCompatibleDC(pDC);
	pMaskDC->SelectObject(bmpMask);
	pImage->Draw(
		pSrcDC,
		CRect(0, 0, w, h),
		CRect(0, 0, w, h)
	);
	COLORREF bg = pSrcDC->GetPixel(0, 0);
	pSrcDC->SetBkColor(bg);
	pMaskDC->BitBlt(0, 0, w, h, pSrcDC, 0, 0, SRCCOPY);
	pSrcDC->SetBkColor(RGB(0, 0, 0));
	pSrcDC->SetTextColor(RGB(255, 255, 255));
	pSrcDC->BitBlt(0, 0, w, h, pMaskDC, 0, 0, SRCAND);
	pDC->BitBlt(0, 0, w, h, pMaskDC, 0, 0, SRCAND);
	pDC->BitBlt(0, 0, w, h, pSrcDC, 0, 0, SRCPAINT);
	delete pSrcDC, pMaskDC;
}
*/

void CMy18724FilipLakicevicView::DrawImageTransparent(CDC* pDC, DImage* pImage)
{
	int w = pImage->Width();
	int h = pImage->Height();

	// uzmi boju prvog piksela preko mem DC-a
	CDC mem; mem.CreateCompatibleDC(pDC);
	CBitmap bmp; bmp.CreateCompatibleBitmap(pDC, w, h);
	CBitmap* old = mem.SelectObject(&bmp);

	pImage->Draw(&mem, CRect(0, 0, w, h), CRect(0, 0, w, h));
	COLORREF transp = mem.GetPixel(0, 0);

	mem.SelectObject(old);

	// nacrtaj transparentno (pretpostavljen interfejs iz zadatka)
	pImage->DrawTransparent(pDC, CRect(0, 0, w, h), CRect(0, 0, w, h), transp);
}

void CMy18724FilipLakicevicView::Rotate(CDC* pDC, float angle, bool rightMultiply)
{
	angle = DegToRad(angle);
	XFORM xform;
	xform.eM11 = cos(angle);
	xform.eM12 = sin(angle);
	xform.eM21 = -sin(angle);
	xform.eM22 = cos(angle);
	xform.eDx = 0.0;
	xform.eDy = 0.0;
	pDC->ModifyWorldTransform(&xform, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);
}


void CMy18724FilipLakicevicView::DrawArm(CDC* pDC)
{
	int s = pDC->SaveDC();

	Translate(pDC, -10.0f, -10.0f, false);

	// crtaj u originalnoj veličini na (0,0) posle ovog translate-a
	DrawImageTransparent(pDC, m_imgArm);

	pDC->RestoreDC(s);
}

void CMy18724FilipLakicevicView::DrawBasket(CDC* pDC, int r)
{
	int s0 = pDC->SaveDC();

	// 1) slika (skalirana) centrirana u (0,0)
	int w = m_imgBasket->Width();
	int h = m_imgBasket->Height();

	// skala samo za sliku
	Scale(pDC, 0.675f, 0.675f, false);
	Translate(pDC, -w / 2.0f, -h / 2.0f, false);

	DrawImageTransparent(pDC, m_imgBasket);

	pDC->RestoreDC(s0);

	// 2) tekst (bez dodatne skale), centriran i pod -30°
	int s1 = pDC->SaveDC();

	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(RGB(0, 0, 120)); // tamno plava

	LOGFONT lf{};
	lf.lfHeight = (LONG)(0.9 * r);
	lf.lfWeight = FW_BOLD;
	_tcscpy_s(lf.lfFaceName, _T("Verdana"));
	lf.lfEscapement = -300;     // -30° (u 0.1°)
	lf.lfOrientation = -300;

	CFont font; font.CreateFontIndirect(&lf);
	CFont* oldF = pDC->SelectObject(&font);

	CString txt = _T("R_G");
	CSize ts = pDC->GetTextExtent(txt);

	pDC->TextOutW(-ts.cx / 2, -ts.cy / 2, txt);

	pDC->SelectObject(oldF);
	pDC->RestoreDC(s1);
}


void CMy18724FilipLakicevicView::DrawBasketCouple(CDC* pDC, int l, int r, float angle)
{
	int s = pDC->SaveDC();

	// cela grupa prati rotaciju prve korpe
	Rotate(pDC, angle, false);

	// prva korpa u (0,0)
	DrawBasket(pDC, r);

	// drzach: u tacki (0.8*r, 0), rotiraj arm za -90 da bude horizontalan
	{
		int sA = pDC->SaveDC();
		Translate(pDC, 0.8f * r, 0.0f, false);
		Rotate(pDC, -90.0f, false);
		DrawArm(pDC);
		pDC->RestoreDC(sA);
	}

	// druga korpa: centar u (l,0) (u istom rotiranom sistemu)
	{
		int sB = pDC->SaveDC();
		Translate(pDC, (float)l, 0.0f, false);
		DrawBasket(pDC, r);
		pDC->RestoreDC(sB);
	}

	pDC->RestoreDC(s);
}


void CMy18724FilipLakicevicView::DrawPlatform(CDC* pDC, int l, int r, double angle)
{
	int s = pDC->SaveDC();

	// centralna korpa rotirana za +angle
	{
		int sc = pDC->SaveDC();
		Rotate(pDC, (float)angle, false);
		DrawBasket(pDC, r);
		pDC->RestoreDC(sc);
	}

	// 6 parova pravilno (na 60°), svaki za -angle
	for (int i = 0; i < 6; i++)
	{
		int sp = pDC->SaveDC();
		Rotate(pDC, i * 60.0f, false);
		Translate(pDC, (float)l, 0.0f, false);
		DrawBasketCouple(pDC, l, r, (float)(-angle));
		pDC->RestoreDC(sp);
	}

	pDC->RestoreDC(s);
}

void CMy18724FilipLakicevicView::DrawCarousel(CDC* pDC, int h, int r,
	double offset, double alpha, double beta, double angle)
{
	const double PI = 3.14159265358979323846;

	int s = pDC->SaveDC();

	// pomeraj cele “glave” ringušpila levo/desno
	Translate(pDC, (float)offset, 0.0f, false);

	// rotacija korpe usled pređenog puta (kotrljanje): theta = s/r (u rad)
	double spinDeg = -(offset / r) * (180.0 / PI);

	// nacrtaj početnu korpu sa spinom
	{
		int sb = pDC->SaveDC();
		Rotate(pDC, (float)spinDeg, false);
		DrawBasket(pDC, r);
		pDC->RestoreDC(sb);
	}

	// prvi držač (inicijalno uspravan -> ka gore, zato +180)
	{
		int sa = pDC->SaveDC();

		Rotate(pDC, (float)(180.0 + alpha), false);
		DrawArm(pDC);

		// do manje osovine prvog
		Translate(pDC, 0.0f, (float)h, false);

		// drugi držač, beta relativno na prvi
		Rotate(pDC, (float)beta, false);
		DrawArm(pDC);

		// do manje osovine drugog
		Translate(pDC, 0.0f, (float)h, false);

		// platforma
		DrawPlatform(pDC, m_l, m_r, angle);

		pDC->RestoreDC(sa);
	}

	pDC->RestoreDC(s);
}


void CMy18724FilipLakicevicView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) {
	switch (nChar)
	{
	case 'Q': m_offset -= 10; break;
	case 'W': m_offset += 10; break;

	case 'A': m_alpha -= 5; break;
	case 'S': m_alpha += 5; break;

	case 'D': m_beta -= 5; break;
	case 'F': m_beta += 5; break;

	case 'E': m_angle -= 5; break;
	case 'R': m_angle += 5; break;
	}

	// (opciono) clamp da ne ode u beskonačnost
	if (m_offset < -400) m_offset = -400;
	if (m_offset > 400) m_offset = 400;

	Invalidate();
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}


BOOL CMy18724FilipLakicevicView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CMy18724FilipLakicevicView drawing

void CMy18724FilipLakicevicView::OnDraw(CDC* pDC) {

	CMy18724FilipLakicevicDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	CRect rect;
	GetClientRect(&rect);
	CDC memDC;
	memDC.CreateCompatibleDC(pDC);
	CBitmap bmp;
	bmp.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());
	CBitmap* oldbmp = memDC.SelectObject(&bmp);
	int oldmode = memDC.SetGraphicsMode(GM_ADVANCED);
	XFORM form;
	memDC.GetWorldTransform(&form);
	DrawBackground(&memDC);

	//ukljucuju DrawBakcg ti je isto
	//odavde ti ide ako hoces da ti bude na polovini ekrana slika koju crtas
	//ali vodi red, jer to zavisi i koliko ti je background slika
	//znaci ovaj translate u zavinsoti od zadatka

	//Translate(&memDC, rect.Width() / 2, rect.Height() - 200, false);
	// ovo gore Translate se poziva u zavisnosti od zadatka

	//ovo pozivas u zavisnosti od fje, znaci moze i bez translate i sa bez

	//DrawLampShadow(&memDC);
	//DrawLamp(&memDC, false);
	//Translate(&memDC, -rect.Width() / 2, -(rect.Height() - 200), false);
	// ovo gore je primer iz blanketa, radi se u zavisnosti od zadatka

	int s = memDC.SaveDC();

	// pozicioniranje: X centar prozora, Y malo iznad dna
	Translate(&memDC, rect.Width() / 2.0f, rect.Height() - 2.0f * m_r, false);

	DrawCarousel(&memDC, m_l, m_r, m_offset, m_alpha, m_beta, m_angle);

	memDC.RestoreDC(s);

	//isto
	memDC.SetWorldTransform(&form);
	pDC->BitBlt(0, 0, rect.Width(), rect.Height(), &memDC, 0, 0, SRCCOPY);
	memDC.SetGraphicsMode(oldmode);
	memDC.SelectObject(oldbmp);
}


// CMy18724FilipLakicevicView printing


void CMy18724FilipLakicevicView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CMy18724FilipLakicevicView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMy18724FilipLakicevicView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMy18724FilipLakicevicView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CMy18724FilipLakicevicView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CMy18724FilipLakicevicView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CMy18724FilipLakicevicView diagnostics

#ifdef _DEBUG
void CMy18724FilipLakicevicView::AssertValid() const
{
	CView::AssertValid();
}

void CMy18724FilipLakicevicView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMy18724FilipLakicevicDoc* CMy18724FilipLakicevicView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMy18724FilipLakicevicDoc)));
	return (CMy18724FilipLakicevicDoc*)m_pDocument;
}
#endif //_DEBUG


// CMy18724FilipLakicevicView message handlers
