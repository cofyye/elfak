
// 18724_Filip_LakicevicView.h : interface of the CMy18724FilipLakicevicView class
//

#include "DImage.h"

#pragma once


class CMy18724FilipLakicevicView : public CView
{
protected:
	float DegToRad(float deg);
	// create from serialization only
	CMy18724FilipLakicevicView() noexcept;
	DECLARE_DYNCREATE(CMy18724FilipLakicevicView)

// Attributes
public:
	CMy18724FilipLakicevicDoc* GetDocument() const;

	DImage* background;

	DImage* m_imgBackground = nullptr;
	DImage* m_imgBasket = nullptr;
	DImage* m_imgArm = nullptr;

	double m_offset = 0;   // Q/W
	double m_alpha = 0;   // A/S
	double m_beta = 0;   // D/F
	double m_angle = 0;   // E/R

	const int m_r = 50;
	const int m_l = 182;

	// ostale slike...

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CMy18724FilipLakicevicView();
	void Translate(CDC* pDC, float dx, float dy, bool rightMultiply);
	void Scale(CDC* pDC, float sX, float sY, bool rightMultiply);
	void DrawBackground(CDC* pDC);
	//void DrawImgTransparent(CDC* pDC, DImage* pImage);
	void Rotate(CDC* pDC, float angleDeg, bool rightMultiply);
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	void DrawImageTransparent(CDC* pDC, DImage* pImage);
	void DrawArm(CDC* pDC);
	void DrawBasket(CDC* pDC, int r);
	void DrawBasketCouple(CDC* pDC, int l, int r, float angle);
	void DrawPlatform(CDC* pDC, int l, int r, double angle);
	void DrawCarousel(CDC* pDC, int h, int r, double offset, double alpha, double beta, double angle);
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in 18724_Filip_LakicevicView.cpp
inline CMy18724FilipLakicevicDoc* CMy18724FilipLakicevicView::GetDocument() const
   { return reinterpret_cast<CMy18724FilipLakicevicDoc*>(m_pDocument); }
#endif

