﻿
// 18724_Filip_LakicevicView.cpp : implementation of the CMy18724FilipLakicevicView class
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "18724_Filip_Lakicevic.h"
#endif

#include "18724_Filip_LakicevicDoc.h"
#include "18724_Filip_LakicevicView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#include "DImage.h"


// CMy18724FilipLakicevicView

IMPLEMENT_DYNCREATE(CMy18724FilipLakicevicView, CView)

BEGIN_MESSAGE_MAP(CMy18724FilipLakicevicView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CMy18724FilipLakicevicView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_WM_KEYDOWN()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()

// CMy18724FilipLakicevicView construction/destruction

float CMy18724FilipLakicevicView::DegToRad(float deg) {
	return deg * 3.14f / 180.0f;
}

CMy18724FilipLakicevicView::CMy18724FilipLakicevicView() noexcept
{
	// TODO: add construction code here

	background = new DImage();

	// ostale slike

	background->Load(CString("./Slike/background.jpg"));

	// istali loadovi

}

CMy18724FilipLakicevicView::~CMy18724FilipLakicevicView()
{

	delete background;

	//ostali deleteovi
}

void CMy18724FilipLakicevicView::Translate(CDC* pDC, float dx, float dy, bool rightMultiply) {
	XFORM xf{ 1, 0, 0, 1, dx, dy };
	pDC->ModifyWorldTransform(&xf, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);
}

void CMy18724FilipLakicevicView::Scale(CDC* pDC, float sX, float sY, bool rightMultiply) {
	XFORM xform{};
	xform.eM11 = sX;
	xform.eM12 = 0.0;
	xform.eM21 = 0.0;
	xform.eM22 = sY;
	xform.eDx = 0.0;
	xform.eDy = 0.0;
	pDC->ModifyWorldTransform(&xform, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);
}

BOOL CMy18724FilipLakicevicView::OnEraseBkgnd(CDC* pDC) {
	return true;
}

// TEXT: Ako zatreba odkomentarisi
//void CMy18724FilipLakicevicView::Mirror(CDC* pDC, bool mx, bool my,
	//bool rightMultiply)
//{
	//Scale(pDC, mx ? -1 : 1, my ? -1 : 1, rightMultiply);
//}

// Crtanje pozadinske slike u prirodnoj velicini
/*
void CMy18724FilipLakicevicView::DrawBackground(CDC* pDC)
{
	CRect client;
	GetClientRect(&client);
	background->Draw(pDC, CRect(0, 0, background->Width(),
	background->Height()), client);
}
*/



/* Crtanje pozadinske slike tako da
je uvek centrirana po X-osi, prilikom promene veličine prozora, a donja
ivica se poklapa sa
donjom ivicom klijentskog dela prozora */
void CMy18724FilipLakicevicView::DrawBackground(CDC* pDC) {
	CRect client;
	GetClientRect(&client);
	int x, y, w, h;
	x = (client.Width() - background->Width()) / 2;
	w = x + background->Width();
	y = client.Height() - background->Height();
	h = y + background->Height();
	background->Draw(pDC, CRect(0, 0, background->Width(),
	background->Height()), CRect(x, y, w, h));
}


void CMy18724FilipLakicevicView::DrawImgTransparent(CDC* pDC, DImage* pImage) {
	int w = pImage->Width();
	int h = pImage->Height();
	CBitmap bmpImage, bmpMask;
	bmpImage.CreateCompatibleBitmap(pDC, w, h);
	bmpMask.CreateBitmap(w, h, 1, 1, NULL);
	CDC* pSrcDC = new CDC();
	pSrcDC->CreateCompatibleDC(pDC);
	pSrcDC->SelectObject(bmpImage);
	CDC* pMaskDC = new CDC();
	pMaskDC->CreateCompatibleDC(pDC);
	pMaskDC->SelectObject(bmpMask);
	pImage->Draw(
		pSrcDC,
		CRect(0, 0, w, h),
		CRect(0, 0, w, h)
	);
	COLORREF bg = pSrcDC->GetPixel(0, 0);
	pSrcDC->SetBkColor(bg);
	pMaskDC->BitBlt(0, 0, w, h, pSrcDC, 0, 0, SRCCOPY);
	pSrcDC->SetBkColor(RGB(0, 0, 0));
	pSrcDC->SetTextColor(RGB(255, 255, 255));
	pSrcDC->BitBlt(0, 0, w, h, pMaskDC, 0, 0, SRCAND);
	pDC->BitBlt(0, 0, w, h, pMaskDC, 0, 0, SRCAND);
	pDC->BitBlt(0, 0, w, h, pSrcDC, 0, 0, SRCPAINT);
	delete pSrcDC, pMaskDC;
}


void CMy18724FilipLakicevicView::Rotate(CDC* pDC, float angle, bool rightMultiply)
{
	angle = DegToRad(angle);
	XFORM xform;
	xform.eM11 = cos(angle);
	xform.eM12 = sin(angle);
	xform.eM21 = -sin(angle);
	xform.eM22 = cos(angle);
	xform.eDx = 0.0;
	xform.eDy = 0.0;
	pDC->ModifyWorldTransform(&xform, rightMultiply ? MWT_RIGHTMULTIPLY : MWT_LEFTMULTIPLY);
}


void CMy18724FilipLakicevicView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) {
		Invalidate();
}


BOOL CMy18724FilipLakicevicView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CMy18724FilipLakicevicView drawing

void CMy18724FilipLakicevicView::OnDraw(CDC* pDC) {

	CMy18724FilipLakicevicDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	CRect rect;
	GetClientRect(&rect);
	CDC memDC;
	memDC.CreateCompatibleDC(pDC);
	CBitmap bmp;
	bmp.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());
	CBitmap* oldbmp = memDC.SelectObject(&bmp);
	int oldmode = memDC.SetGraphicsMode(GM_ADVANCED);
	XFORM form;
	memDC.GetWorldTransform(&form);
	DrawBackground(&memDC);

	//ukljucuju DrawBakcg ti je isto
	//odavde ti ide ako hoces da ti bude na polovini ekrana slika koju crtas
	//ali vodi red, jer to zavisi i koliko ti je background slika
	//znaci ovaj translate u zavinsoti od zadatka

	//Translate(&memDC, rect.Width() / 2, rect.Height() - 200, false);
	// ovo gore Translate se poziva u zavisnosti od zadatka

	//ovo pozivas u zavisnosti od fje, znaci moze i bez translate i sa bez

	//DrawLampShadow(&memDC);
	//DrawLamp(&memDC, false);
	//Translate(&memDC, -rect.Width() / 2, -(rect.Height() - 200), false);
	// ovo gore je primer iz blanketa, radi se u zavisnosti od zadatka

	//isto
	memDC.SetWorldTransform(&form);
	pDC->BitBlt(0, 0, rect.Width(), rect.Height(), &memDC, 0, 0, SRCCOPY);
	memDC.SetGraphicsMode(oldmode);
	memDC.SelectObject(oldbmp);
}


// CMy18724FilipLakicevicView printing


void CMy18724FilipLakicevicView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CMy18724FilipLakicevicView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMy18724FilipLakicevicView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMy18724FilipLakicevicView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CMy18724FilipLakicevicView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CMy18724FilipLakicevicView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CMy18724FilipLakicevicView diagnostics

#ifdef _DEBUG
void CMy18724FilipLakicevicView::AssertValid() const
{
	CView::AssertValid();
}

void CMy18724FilipLakicevicView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMy18724FilipLakicevicDoc* CMy18724FilipLakicevicView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMy18724FilipLakicevicDoc)));
	return (CMy18724FilipLakicevicDoc*)m_pDocument;
}
#endif //_DEBUG


// CMy18724FilipLakicevicView message handlers
