//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Robot.rc
//
#define IDD_ABOUTBOX				100
#define IDP_OLE_INIT_FAILED			100
#define IDR_MAINFRAME				128
#define IDR_RobotTYPE				130

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE	310
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		310
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
