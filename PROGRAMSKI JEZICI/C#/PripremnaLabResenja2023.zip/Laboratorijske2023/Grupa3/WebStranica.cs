﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa3
{
    class WebStranica : Stavka
    {
        public WebStranica(int godina, string nazivLink)
      : base(godina, nazivLink)
        {
        }

        public WebStranica()
        { }

        public override string Tekst
        { 
            get
            {
                return nazivLink + ", " + godina;
            }
        }
    }
}
