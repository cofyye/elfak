﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa3
{
    class Knjiga : Stavka
    {
        List<string> autori;
        string mesto;

        public Knjiga()
        { }

        public Knjiga(int godina, string nazivLink, List<string> autori, string mesto)
            : base(godina, nazivLink)
        {
            this.autori = autori;
            this.mesto = mesto;
        }

        public override string Tekst
        {
            get
            {
                String toReturn = nazivLink;
                foreach (string item in autori)
                {
                    toReturn += (", " + item);
                }
                toReturn += (", " + mesto);
                toReturn += (", " + godina);
                return toReturn;
            }
        }

        public override void Upis(StreamWriter sw)
        {
            base.Upis(sw);
            sw.WriteLine(autori.Count);
            for (int i = 0; i < autori.Count; i++)
                sw.WriteLine(autori[i]);
            sw.WriteLine(mesto);
        }

        public override void Citanje(StreamReader sr)
        {
            base.Citanje(sr);
            int brojEl = Int32.Parse(sr.ReadLine());
            if (autori == null)
                autori = new List<string>();
            else
                autori.Clear();
            for (int i = 0; i < brojEl; i++)
            {
                String autor = sr.ReadLine();
                this.autori.Add(autor);
            }
            this.mesto = sr.ReadLine();
        }
    }
}
