﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa3
{
    abstract class Stavka
    {
        protected int godina;
        protected string nazivLink;

        public Stavka()
        { }

        public Stavka(int godina, string nazivLink)
        {
            this.godina = godina;
            this.nazivLink = nazivLink;
        }

        public int Godina
        {
            get
            {
                return this.godina;
            }
        }

        abstract public string Tekst
        {
            get;
        }

        public virtual void Upis(StreamWriter sw)
        {
            sw.WriteLine(godina);
            sw.WriteLine(nazivLink);
        }

        public virtual void Citanje(StreamReader sr)
        {
            godina = Int32.Parse(sr.ReadLine());
            nazivLink = sr.ReadLine();
        }
    }
}
