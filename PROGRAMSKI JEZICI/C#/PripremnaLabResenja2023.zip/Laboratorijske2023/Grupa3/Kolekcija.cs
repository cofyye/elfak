﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa3
{
    class Kolekcija<T> where T : Stavka
    {
        List<T> stavke;

        public Kolekcija()
        {
            stavke = new List<T>();
        }

        public void Dodaj(T stavka)
        {
            stavke.Add(stavka);
        }

        public T this[int i]
        {
            get
            {
                return stavke[i];
            }
            set
            {
                stavke[i] = value;
            }
        }

        public int BrojElemenata
        {
            get
            {
                return stavke.Count;
            }
        }
    }
}
