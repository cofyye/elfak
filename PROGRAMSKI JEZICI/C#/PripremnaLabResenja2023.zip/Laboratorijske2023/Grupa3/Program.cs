﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa3
{
    class Program
    {
        static void Main(string[] args)
        {
            Literatura l1 = new Literatura();
            List<String> autori = new List<string>();
            
            autori.Add("Dick Grune");
            autori.Add("Kees van Reeuwijk");
            autori.Add("Henri E. Bal");
            l1.Dodaj(new Knjiga(2012, "Modern Compiler Design", autori, "Amsterdam"));

            autori = new List<string>();
            autori.Add("James W. Cooley");
            autori.Add("John W. Tukey");
            l1.Dodaj(new Clanak(1965, "An algorithm for the machine calculation of complex Fourier series",
                "Mathematics of Computation", autori, "New York"));

            l1.Dodaj(new WebStranica(2023, @"https://docs.nvidia.com/cuda/pdf/CUDA_C_Programming_Guide.pdf"));
            Console.WriteLine("Originalna literatura");
            l1.Prikaz();
            l1.Upis("fajl.txt");

            Literatura l2 = new Literatura();
            l2.Citanje("fajl.txt");
            Console.WriteLine();
            Console.WriteLine("Literatura pročitana iz fajla:");
            l2.Prikaz();

            l2.SortGodina(false);
            Console.WriteLine();
            Console.WriteLine("Sortirano po godini rastuće:");
            l2.Prikaz();

            l2.SortTekst(true);
            Console.WriteLine();
            Console.WriteLine("Sortirano po tekstu opadajuće:");
            l2.Prikaz();
        }
    }
}
