﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa3
{
    class Literatura
    {
        const int MAX_STAVKE = 30;
        Kolekcija<Stavka> kolekcija;

        public Literatura()
        {
            kolekcija = new Kolekcija<Stavka>();
        }

        public void Dodaj(Stavka s)
        {
            if (kolekcija.BrojElemenata < MAX_STAVKE)
                kolekcija.Dodaj(s);
            else
                throw new NemaMesta("Imate vec " + MAX_STAVKE + " stavki u literaturi.");
        }

        public void SortGodina(bool opadajuci)
        {
            for (int i = 0; i < kolekcija.BrojElemenata - 1; i++)
            {
                int selectIndex = i;
                for (int j = i + 1; j < kolekcija.BrojElemenata; j++)
                {
                    if (opadajuci && kolekcija[j].Godina > kolekcija[selectIndex].Godina
                        || !opadajuci && kolekcija[j].Godina < kolekcija[selectIndex].Godina)
                        selectIndex = j;
                }
                if (selectIndex != i)
                {
                    Stavka tmp = kolekcija[i];
                    kolekcija[i] = kolekcija[selectIndex];
                    kolekcija[selectIndex] = tmp;
                }
            }
        }

        public void SortTekst(bool opadajuci)
        {
            for (int i = 0; i < kolekcija.BrojElemenata - 1; i++)
            {
                int selectIndex = i;
                for (int j = i + 1; j < kolekcija.BrojElemenata; j++)
                {
                    if (opadajuci && kolekcija[j].Tekst.CompareTo(kolekcija[selectIndex].Tekst) > 0
                        || !opadajuci && kolekcija[j].Tekst.CompareTo(kolekcija[selectIndex].Tekst) < 0)
                        selectIndex = j;
                }
                if (selectIndex != i)
                {
                    Stavka tmp = kolekcija[i];
                    kolekcija[i] = kolekcija[selectIndex];
                    kolekcija[selectIndex] = tmp;
                }
            }
        }

        public Stavka this[int i]
        {
            get
            {
                return kolekcija[i];
            }
        }

        public void Upis(string putanja)
        {
            using (StreamWriter sw = new StreamWriter(putanja))
            {
                sw.WriteLine(kolekcija.BrojElemenata);
                int tip = 0;
                for (int i = 0; i < kolekcija.BrojElemenata; i++)
                {
                    if (kolekcija[i].GetType() == typeof(Knjiga))
                        tip = 1;
                    else if (kolekcija[i].GetType() == typeof(Clanak))
                        tip = 2;
                    else if (kolekcija[i].GetType() == typeof(WebStranica))
                        tip = 3;
                    sw.WriteLine(tip);
                    kolekcija[i].Upis(sw);
                }
            }
        }

        public void Citanje(string putanja)
        {
            using (StreamReader sr = new StreamReader(putanja))
            {
                int brojElemenata = Int32.Parse(sr.ReadLine());
                for (int i = 0; i < brojElemenata; i++)
                {
                    int tip = Int32.Parse(sr.ReadLine());
                    Stavka novaStavka = null;
                    switch (tip)
                    {
                        case 1:
                            novaStavka = new Knjiga();
                            break;
                        case 2:
                            novaStavka = new Clanak();
                            break;
                        case 3:
                            novaStavka = new WebStranica();
                            break;
                        default:
                            break;
                    }
                    novaStavka.Citanje(sr);
                    kolekcija.Dodaj(novaStavka);
                }
            }
        }

        public void Prikaz()
        {
            for (int i = 0; i < kolekcija.BrojElemenata; i++)
            {
                Console.WriteLine(kolekcija[i].Tekst);
            }
        }

    }
}
