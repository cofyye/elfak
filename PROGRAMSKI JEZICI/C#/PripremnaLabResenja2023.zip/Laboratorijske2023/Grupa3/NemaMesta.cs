﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa3
{
    class NemaMesta : Exception
    {
        public NemaMesta(string poruka) : base(poruka)
        {
        }
    }
}
