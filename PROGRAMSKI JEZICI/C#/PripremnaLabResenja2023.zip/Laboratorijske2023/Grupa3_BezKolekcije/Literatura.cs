﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa3
{
    class Literatura
    {
        const int MAX_STAVKE = 30;
        List<Stavka> stavke;

        public Literatura()
        {
            stavke = new List<Stavka>();
        }

        public void Dodaj(Stavka s)
        {
            if (stavke.Count < MAX_STAVKE)
                stavke.Add(s);
            else
                throw new NemaMesta("Imate vec " + MAX_STAVKE + " stavki u literaturi.");
        }

        public void SortGodina(bool opadajuci)
        {
            for (int i = 0; i < stavke.Count - 1; i++)
            {
                int selectIndex = i;
                for (int j = i + 1; j < stavke.Count; j++)
                {
                    if (opadajuci && stavke[j].Godina > stavke[selectIndex].Godina
                        || !opadajuci && stavke[j].Godina < stavke[selectIndex].Godina)
                        selectIndex = j;
                }
                if (selectIndex != i)
                {
                    Stavka tmp = stavke[i];
                    stavke[i] = stavke[selectIndex];
                    stavke[selectIndex] = tmp;
                }
            }
        }

        public void SortTekst(bool opadajuci)
        {
            for (int i = 0; i < stavke.Count - 1; i++)
            {
                int selectIndex = i;
                for (int j = i + 1; j < stavke.Count; j++)
                {
                    if (opadajuci && stavke[j].Tekst.CompareTo(stavke[selectIndex].Tekst) > 0
                        || !opadajuci && stavke[j].Tekst.CompareTo(stavke[selectIndex].Tekst) < 0)
                        selectIndex = j;
                }
                if (selectIndex != i)
                {
                    Stavka tmp = stavke[i];
                    stavke[i] = stavke[selectIndex];
                    stavke[selectIndex] = tmp;
                }
            }
        }

        public Stavka this[int i]
        {
            get
            {
                return stavke[i];
            }
        }

        public void Upis(string putanja)
        {
            using (StreamWriter sw = new StreamWriter(putanja))
            {
                sw.WriteLine(stavke.Count);
                int tip = 0;
                foreach (Stavka s in stavke)
                {
                    if (s.GetType() == typeof(Knjiga))
                        tip = 1;
                    else if (s.GetType() == typeof(Clanak))
                        tip = 2;
                    else if (s.GetType() == typeof(WebStranica))
                        tip = 3;
                    sw.WriteLine(tip);
                    s.Upis(sw);
                }
            }
        }

        public void Citanje(string putanja)
        {
            using (StreamReader sr = new StreamReader(putanja))
            {
                int brojElemenata = Int32.Parse(sr.ReadLine());
                for (int i = 0; i < brojElemenata; i++)
                {
                    int tip = Int32.Parse(sr.ReadLine());
                    Stavka novaStavka = null;
                    switch (tip)
                    {
                        case 1:
                            novaStavka = new Knjiga();
                            break;
                        case 2:
                            novaStavka = new Clanak();
                            break;
                        case 3:
                            novaStavka = new WebStranica();
                            break;
                        default:
                            break;
                    }
                    novaStavka.Citanje(sr);
                    stavke.Add(novaStavka);
                }
            }
        }

        public void Prikaz()
        {
            foreach (Stavka s in stavke)
            {
                Console.WriteLine(s.Tekst);
            }
        }

    }
}
