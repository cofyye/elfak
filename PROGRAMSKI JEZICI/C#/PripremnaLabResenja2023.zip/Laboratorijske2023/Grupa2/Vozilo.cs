﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa2
{
    abstract class Vozilo
    {
        String regOznaka, proizvodjac, model;

        public Vozilo()
        {
        }

        public Vozilo(String regOznaka, String proizvodjac, String model)
        {
            this.regOznaka = regOznaka;
            this.proizvodjac = proizvodjac;
            this.model = model;
        }
        abstract public int ParkingMesta
        {
            get;
        }

        public string RegOznaka
        {
            get { return regOznaka; }
        }

        public virtual void Upis(BinaryWriter bw)
        {
            bw.Write(regOznaka);
            bw.Write(proizvodjac);
            bw.Write(model);
        }
        public virtual void Citanje(BinaryReader br)
        {
            regOznaka = br.ReadString();
            proizvodjac = br.ReadString();
            model = br.ReadString();
        }

        public override string ToString()
        {
            return proizvodjac + " " + model + " " + regOznaka;
        }
    }
}
