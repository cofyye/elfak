﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa2
{
    class Program
    {
        static void Main(string[] args)
        {
            Parking p = new Parking(5, 6);
            Automobil auto1 = new Automobil("NI-300-NI", "Alfa Romeo", "Giulia");
            Automobil auto2 = new Automobil("NI-001-ZA", "Zastava", "Yugo Cabrio");
            Kamion kamion1 = new Kamion("NI-234-CS", "Mercedes", "Atego", 4, 7.5f);
            Autobus bus1 = new Autobus("NI-333-EL", "MAN", "Lion's Coach", 50);

            p.Parkiraj(auto1);
            p.Parkiraj(auto2);
            p.Parkiraj(bus1);
            p.Parkiraj(kamion1);

            p.Prikaz();

            p.NapustiParking(kamion1);
            p.Prikaz();

            p.Upis("fajl.bin");

            Parking p2 = new Parking();
            p2.Citanje("fajl.bin");
            p2.Prikaz();
        }
    }
}
