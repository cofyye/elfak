﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa2
{
    class Parking
    {
        Matrica<Vozilo> matrica;

        public Parking()
        {

        }
        public Parking(int brojVrsta, int brojKolona)
        {
            this.matrica = new Matrica<Vozilo>(brojVrsta, brojKolona);
        }
       
        public void Parkiraj(Vozilo v)
        {
            // traženje potrebnog broja praznih mesta u nizu
            int startI = -1,startJ = -1;
            for (int i = 0; i < matrica.BrojVrsta && startI == -1; i++)
            {
                int praznaMesta = 0;
                for (int j = 0; j < matrica.BrojKolona && startJ == -1; j++)
                {
                    if (matrica[i, j] == null)
                    {
                        praznaMesta++;
                        if (praznaMesta == v.ParkingMesta)
                        {
                            startI = i;
                            startJ = j - praznaMesta + 1;
                        }
                    }
                    else
                        praznaMesta = 0;
                }
            }
            // ako je pronadjen dovoljan broj praznih mesta ubaciti vozilo na ta mesta
            if (startI != -1 && startJ != -1)
            {
                for (int j = 0; j < v.ParkingMesta; j++)
                    matrica[startI, startJ + j] = v;
            }
            // u suprotnom baciti izuzetak
            else
                throw new NemaMesta("Nema dovoljno mesta za vozilo: " + v);
        }

        public void NapustiParking(Vozilo v)
        {
            for (int i = 0; i < matrica.BrojVrsta; i++)
            {
                for (int j = 0; j < matrica.BrojKolona; j++)
                {
                    if (matrica[i, j] != null 
                        && matrica[i,j].RegOznaka == v.RegOznaka)
                    {
                        for (int k = 0; k < v.ParkingMesta; k++)
                            matrica[i, j + k] = null;
                        return;
                    }
                }
            }
        }

        public void Prikaz()
        {
            Console.WriteLine("Zauzetost parkinga: ");
            for (int i = 0; i < matrica.BrojVrsta; i++)
            {
                for (int j = 0; j < matrica.BrojKolona; j++)
                {
                    Console.Write(((matrica[i, j] == null) ? 0 : 1) + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine("Vozila na parkingu: ");
            for (int i = 0; i < matrica.BrojVrsta; i++)
            {
                int j = 0;
                while (j < matrica.BrojKolona)
                {
                    if (matrica[i, j] != null)
                    {
                        Console.WriteLine(matrica[i, j]);
                        j += matrica[i, j].ParkingMesta;
                    }
                    else
                        j++;
                }
            }
        }
        private int BrojVozila()
        {
            int brojVozila = 0;
            for (int i = 0; i < matrica.BrojVrsta; i++)
            {
                int j = 0;
                while (j < matrica.BrojKolona)
                {
                    if (matrica[i, j] != null)
                    {
                        brojVozila++;
                        j += matrica[i, j].ParkingMesta;
                    }
                    else
                        j++;
                }
            }
            return brojVozila;
        }
        public void Upis(String putanja)
        {
            using (BinaryWriter bw = new BinaryWriter(new FileStream(putanja, FileMode.Create)))
            {
                bw.Write(matrica.BrojVrsta);
                bw.Write(matrica.BrojKolona);
                bw.Write(BrojVozila());
                for (int i = 0; i < matrica.BrojVrsta; i++)
                {
                    int j = 0;
                    while (j < matrica.BrojKolona)
                    {
                        if (matrica[i, j] != null)
                        {
                            if (matrica[i, j].GetType() == typeof(Automobil))
                                bw.Write(1);
                            else if (matrica[i, j].GetType() == typeof(Autobus))
                                bw.Write(2);
                            else
                                bw.Write(3);
                            matrica[i, j].Upis(bw);
                            bw.Write(i);
                            bw.Write(j);
                            j += matrica[i, j].ParkingMesta;
                        }
                        else
                            j++;
                    }
                }
            }
        }

        public void Citanje(String putanja)
        {
            using (BinaryReader br = new BinaryReader(new FileStream(putanja, FileMode.Open)))
            {
                int brojVrsta = br.ReadInt32();
                int brojKolona = br.ReadInt32();
                matrica = new Matrica<Vozilo>(brojVrsta, brojKolona);
                int brojVozila = br.ReadInt32();
                for (int v = 0; v < brojVozila; v++)
                {
                    int tipVozila = br.ReadInt32();
                    Vozilo vozilo = null;
                    switch (tipVozila)
                    {
                        case 1:
                            vozilo = new Automobil();
                            break;
                        case 2:
                            vozilo = new Autobus();
                            break;
                        case 3:
                            vozilo = new Kamion();
                            break;
                        default:
                            break;
                    }
                    vozilo.Citanje(br);
                    int startI = br.ReadInt32();
                    int startJ = br.ReadInt32();
                    for (int k = 0; k < vozilo.ParkingMesta; k++)
                        matrica[startI, startJ + k] = vozilo;
                }
            }
        }
    }
}
