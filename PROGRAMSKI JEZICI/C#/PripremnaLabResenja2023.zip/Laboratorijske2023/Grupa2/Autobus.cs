﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa2
{
    class Autobus : Vozilo
    {
        int brojPutnika;

        public Autobus()
        {
        }
        public Autobus(string regOznaka, string proizvodjac, string model, int brojPutnika) 
            : base(regOznaka, proizvodjac, model)
        {
            this.brojPutnika = brojPutnika;
        }
        public override int ParkingMesta
        {
            get { return 5; }
        }

        public override void Upis(BinaryWriter bw)
        {
            base.Upis(bw);
            bw.Write(brojPutnika);
        }

        public override void Citanje(BinaryReader br)
        {
            base.Citanje(br);
            brojPutnika = br.ReadInt32();
        }
        public override string ToString()
        {
            return "Autobus: " + base.ToString()
                + ", broj putnika: " + brojPutnika;
        }
    }
}
