﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa2
{
    class Kamion : Vozilo
    {
        int parkingMesta;
        float nosivost;

        public Kamion()
        {
        }

        public Kamion(string regOznaka, string proizvodjac, string model, 
            int parkingMesta, float nosivost) 
            : base(regOznaka, proizvodjac, model)
        {
            this.parkingMesta = parkingMesta;
            this.nosivost = nosivost;
        }

        public override int ParkingMesta
        {
            get { return parkingMesta; }
        }

        public override void Upis(BinaryWriter bw)
        {
            base.Upis(bw);
            bw.Write(parkingMesta);
            bw.Write(nosivost);
        }

        public override void Citanje(BinaryReader br)
        {
            base.Citanje(br);
            parkingMesta = br.ReadInt32();
            nosivost = br.ReadSingle();
        }

        public override string ToString()
        {
            return "Kamion: " + base.ToString()
                + ", parking mesta: " + parkingMesta
                + ", nosivost: " + nosivost;
        }
    }
}
