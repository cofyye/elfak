﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa2
{
    class Matrica<T> where T : Vozilo
    {
        int brojVrsta, brojKolona;
        T[,] matrica;

        public Matrica(int brojVrsta, int brojKolona)
        {
            this.brojKolona = brojKolona;
            this.brojVrsta = brojVrsta;
            matrica = new T[brojVrsta, brojKolona];
        }

        public int BrojVrsta
        {
            get { return this.brojVrsta; }
        }

        public int BrojKolona
        {
            get { return this.brojKolona; }
        }

        public T this[int i, int j]
        {
            get { return matrica[i, j]; }
            set { matrica[i, j] = value; }
        }
    }
}
