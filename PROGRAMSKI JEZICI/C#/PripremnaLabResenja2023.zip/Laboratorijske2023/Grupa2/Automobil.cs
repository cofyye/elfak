﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa2
{
    class Automobil : Vozilo
    {
        public Automobil()
        {
        }

        public Automobil(string regOznaka, string proizvodjac, string model) 
            : base(regOznaka, proizvodjac, model)
        {
        }

        public override int ParkingMesta
        {
            get { return 1; }
        }

        public override string ToString()
        {
            return "Automobil: " + base.ToString();
        }
    }
}
