﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa2
{
    class NemaMesta : Exception
    {
        public NemaMesta(string poruka) : base(poruka)
        {
        }
    }
}
