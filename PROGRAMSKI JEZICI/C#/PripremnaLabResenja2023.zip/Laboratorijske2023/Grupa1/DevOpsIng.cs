﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa1
{
    class DevOpsIng : Zaposleni
    {
        DateTime poslednjiPregled;
        public DevOpsIng()
        {
        }

        public DevOpsIng(string ime, string prezime, float plata, DateTime poslednjiPregled) 
            : base(ime, prezime, plata)
        {
            this.poslednjiPregled = poslednjiPregled;
        }

        public override float Bonus
        {
            get
            {
                if ((DateTime.Today - poslednjiPregled).TotalDays <= 7)
                    return 0.3f * plata;
                else
                    return 0.15f * plata;
            }
        }

        public override string ToString()
        {
            return base.ToString() + ", datum pregleda: " + poslednjiPregled.ToShortDateString();
        }

        public override void Upis(BinaryWriter bw)
        {
            base.Upis(bw);
            bw.Write(poslednjiPregled.ToBinary());
        }

        public override void Citanje(BinaryReader br)
        {
            base.Citanje(br);
            poslednjiPregled = DateTime.FromBinary(br.ReadInt64());
        }
    }
}
