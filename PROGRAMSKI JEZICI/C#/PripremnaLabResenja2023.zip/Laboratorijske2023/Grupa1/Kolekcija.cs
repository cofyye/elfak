﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa1
{
    class Kolekcija<T> where T : Zaposleni
    {
        List<T> lista;

        public Kolekcija()
        {
            this.lista = new List<T>();
        }

        public void Dodaj(T zaposleni)
        {
            lista.Add(zaposleni);
        }

        public int Broj
        {
            get
            {
                return lista.Count;
            }
        }

        public T this[int i]
        {
            get
            {
                return lista[i];
            }
        }
    }
}
