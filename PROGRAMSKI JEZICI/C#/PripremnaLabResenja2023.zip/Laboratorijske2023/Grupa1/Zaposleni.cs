﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa1
{
    abstract class Zaposleni
    {
        String ime, prezime;
        protected float plata;

        public Zaposleni()
        {
        }

        public Zaposleni(String ime, String prezime, float plata)
        {
            this.ime = ime;
            this.prezime = prezime;
            this.plata = plata;
        }

        abstract public float Bonus { get; }

        public override string ToString()
        {
            return ime + " " + prezime + ", osnovna plata: " + plata 
                + ", bonus: " + Bonus;
        }

        virtual public void Upis(BinaryWriter bw)
        {
            bw.Write(ime);
            bw.Write(prezime);
            bw.Write(plata);
        }
        virtual public void Citanje(BinaryReader br)
        {
            ime = br.ReadString();
            prezime = br.ReadString();
            plata = br.ReadSingle();
        }
    }
}
