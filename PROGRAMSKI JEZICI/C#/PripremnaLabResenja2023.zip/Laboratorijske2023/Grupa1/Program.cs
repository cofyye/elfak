﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa1
{
    class Program
    {
        static void Main(string[] args)
        {
            Kompanija k1 = new Kompanija();
            List<String> tehnologije = new List<string>();
            tehnologije.Add("HTML");
            tehnologije.Add("CSS");
            tehnologije.Add("JavaScript");
            k1 = k1 + new WebDeveloper("Jovana", "Jovanović", 4000, tehnologije);
            k1 = k1 + new QAIng("Petra", "Petrović", 2000, 15);
            k1 = k1 + new DevOpsIng("Marko", "Marković", 3000, new DateTime(2023, 5, 9));
            k1.Prikaz();
            k1.Upis("fajl.bin");

            Kompanija k2 = new Kompanija();
            k2.Citanje("fajl.bin");
            k2.Prikaz();

            k2.ProveriBonuse();
        }
    }
}
