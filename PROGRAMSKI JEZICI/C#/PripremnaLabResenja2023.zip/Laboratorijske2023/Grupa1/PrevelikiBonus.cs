﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa1
{
    class PrevelikiBonus : Exception
    {
        public PrevelikiBonus(String msg)
            : base(msg)
        {

        }
    }
}
