﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa1
{
    class WebDeveloper : Zaposleni
    {
        List<String> tehnologije;

        public WebDeveloper()
        {
        }
        public WebDeveloper(String ime, String prezime, float plata, List<String> tehnologije)
            : base(ime, prezime, plata)
        {
            this.tehnologije = tehnologije;
        }
        public override float Bonus
        {
            get
            {
                if (tehnologije.Count > 5)
                    return 0.2f * plata;
                else
                    return 0.1f * plata;
            }
        }
        public override string ToString()
        {
            String toReturn = base.ToString() + ", tehnologije: ";
            for (int i = 0; i < tehnologije.Count; i++)
            {
                toReturn += tehnologije[i];
                if (i != tehnologije.Count - 1)
                    toReturn += ", ";
            }
            return toReturn;
        }

        public override void Upis(BinaryWriter bw)
        {
            base.Upis(bw);
            bw.Write(tehnologije.Count);
            foreach (String item in tehnologije)
            {
                bw.Write(item);
            }
        }

        public override void Citanje(BinaryReader br)
        {
            base.Citanje(br);
            int brojTehnologija = br.ReadInt32();
            if (tehnologije == null)
                tehnologije = new List<string>(brojTehnologija);
            else
                tehnologije.Clear();
            for (int i = 0; i < brojTehnologija; i++)
            {
                tehnologije.Add(br.ReadString());
            }
        }
    }
}
