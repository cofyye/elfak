﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa1
{
    class QAIng : Zaposleni
    {
        int brojTestova;
        public QAIng()
        {

        }
        public QAIng(string ime, string prezime, float plata, int brojTestova) 
            : base(ime, prezime, plata)
        {
            this.brojTestova = brojTestova;
        }

        public override float Bonus
        {
            get
            {
                if (brojTestova > 10)
                    return 0.1f * plata;
                else
                    return 0.05f * plata;
            }
        }
        public override string ToString()
        {
            return base.ToString() + ", broj testova: " + brojTestova;
        }
        public override void Upis(BinaryWriter bw)
        {
            base.Upis(bw);
            bw.Write(brojTestova);
        }

        public override void Citanje(BinaryReader br)
        {
            base.Citanje(br);
            brojTestova = br.ReadInt32();
        }
    }
}
