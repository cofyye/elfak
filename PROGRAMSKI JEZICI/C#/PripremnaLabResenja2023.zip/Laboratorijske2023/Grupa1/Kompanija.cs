﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa1
{
    class Kompanija
    {
        public const float MAX_BONUS = 500;
        Kolekcija<Zaposleni> radnici;

        public Kompanija()
        {
            radnici = new Kolekcija<Zaposleni>();
        }

        public static Kompanija operator +(Kompanija kompanija, Zaposleni zaposleni)
        {
            kompanija.radnici.Dodaj(zaposleni);
            return kompanija;
        }

        public void ProveriBonuse()
        {
            for (int i = 0; i < radnici.Broj; i++)
            {
                if (radnici[i].Bonus > MAX_BONUS)
                    throw new PrevelikiBonus(radnici[i].Bonus.ToString());
            }
        }

        public void Upis(String putanja)
        {
            using (BinaryWriter bw = new BinaryWriter(new FileStream(putanja, FileMode.Create)))
            {
                bw.Write(radnici.Broj);
                for (int i = 0; i < radnici.Broj; i++)
                {
                    Zaposleni z = radnici[i];
                    if (z.GetType() == typeof(WebDeveloper))
                        bw.Write(1);
                    else if (z.GetType() == typeof(QAIng))
                        bw.Write(2);
                    else
                        bw.Write(3);
                    radnici[i].Upis(bw);
                }
            }
        }

        public void Citanje(String putanja)
        {
            using (BinaryReader br = new BinaryReader(new FileStream(putanja, FileMode.Open)))
            {
                int brojRadnika = br.ReadInt32();
                radnici = new Kolekcija<Zaposleni>();
                for (int i = 0; i < brojRadnika; i++)
                {
                    int tipRadnika = br.ReadInt32();
                    Zaposleni z = null; 
                    switch (tipRadnika)
                    {
                        case 1:
                            z = new WebDeveloper();
                            break;
                        case 2:
                            z = new QAIng();
                            break;
                        case 3:
                            z = new DevOpsIng();
                            break;
                        default:
                            break;
                    }
                    z.Citanje(br);
                    radnici.Dodaj(z);
                }
            }
        }

        public void Prikaz()
        {
            for (int i = 0; i < radnici.Broj; i++)
            {
                Console.WriteLine(radnici[i]);
            }
        }
    }
}
